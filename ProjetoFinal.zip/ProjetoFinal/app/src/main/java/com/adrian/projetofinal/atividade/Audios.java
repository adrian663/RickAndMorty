package com.adrian.projetofinal.atividade;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import com.adrian.projetofinal.R;
import com.adrian.projetofinal.fragmentos.Frase1Fragment;
import com.adrian.projetofinal.fragmentos.Frase2Fragment;
import com.adrian.projetofinal.fragmentos.Frase3Fragment;
import com.adrian.projetofinal.fragmentos.Frase4Fragment;
import com.adrian.projetofinal.fragmentos.Frase5Fragment;
import com.adrian.projetofinal.fragmentos.Frase6Fragment;
import com.adrian.projetofinal.fragmentos.Frase7Fragment;

public class Audios extends AppCompatActivity {

    MediaPlayer mp1, mp2, mp3, mp4, mp5, mp6, mp7;
    private Button btnFrase1, btnFrase2, btnFrase3, btnFrase4, btnFrase5, btnFrase6, btnFrase7;
    private Frase1Fragment frase1Fragment;
    private Frase2Fragment frase2Fragment;
    private Frase3Fragment frase3Fragment;
    private Frase4Fragment frase4Fragment;
    private Frase5Fragment frase5Fragment;
    private Frase6Fragment frase6Fragment;
    private Frase7Fragment frase7Fragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audios);

        btnFrase1 = findViewById(R.id.btnFrase1);
        btnFrase2 = findViewById(R.id.btnFrase2);
        btnFrase3 = findViewById(R.id.btnFrase3);
        btnFrase4 = findViewById(R.id.btnFrase4);
        btnFrase5 = findViewById(R.id.btnFrase5);
        btnFrase6 = findViewById(R.id.btnFrase6);
        btnFrase7 = findViewById(R.id.btnFrase7);

        mp1 = MediaPlayer.create(this, R.raw.wabalabdubdub);
        mp2 = MediaPlayer.create(this, R.raw.babababy);
        mp3 = MediaPlayer.create(this, R.raw.caoqueladranaomorty);
        mp4 = MediaPlayer.create(this, R.raw.horadoshow);
        mp5 = MediaPlayer.create(this, R.raw.noticiavoa);
        mp6 = MediaPlayer.create(this, R.raw.trocadalhosdocarilho);
        mp7 = MediaPlayer.create(this, R.raw.vesesummerdaminhafrente);


        frase1Fragment = new Frase1Fragment();
        frase2Fragment = new Frase2Fragment();
        frase3Fragment = new Frase3Fragment();
        frase4Fragment = new Frase4Fragment();
        frase5Fragment = new Frase5Fragment();
        frase6Fragment = new Frase6Fragment();
        frase7Fragment = new Frase7Fragment();

        btnFrase1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                frase1Fragment = new Frase1Fragment();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame_conteudo, frase1Fragment);
                transaction.commit();
                mp1.start();
            }
        });

        btnFrase2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                frase2Fragment = new Frase2Fragment();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame_conteudo, frase2Fragment);
                transaction.commit();
                mp2.start();
            }
        });

        btnFrase3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                frase3Fragment = new Frase3Fragment();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame_conteudo, frase3Fragment);
                transaction.commit();
                mp3.start();
            }
        });

        btnFrase4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                frase4Fragment = new Frase4Fragment();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame_conteudo, frase4Fragment);
                transaction.commit();
                mp4.start();
            }
        });

        btnFrase5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                frase5Fragment = new Frase5Fragment();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame_conteudo, frase5Fragment);
                transaction.commit();
                mp5.start();
            }
        });

        btnFrase6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                frase6Fragment = new Frase6Fragment();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame_conteudo, frase6Fragment);
                transaction.commit();
                mp6.start();
            }
        });

        btnFrase7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                frase7Fragment = new Frase7Fragment();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame_conteudo, frase7Fragment);
                transaction.commit();
                mp7.start();
            }
        });




        //ocultar a barra de ação do android e configurar a activity para a tela cheia.
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

    }
}
package com.adrian.projetofinal.atividade;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.hardware.Sensor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;

import com.adrian.projetofinal.Personagens;
import com.adrian.projetofinal.R;
import com.adrian.projetofinal.SensorPiu;

public class MainActivity extends AppCompatActivity {

    private Button audios, videos, personagens, sensor;
    private ImageView logo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //ocultar a barra de ação do android e configurar a activity para a tela cheia.
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        audios = findViewById(R.id.audios);
        videos = findViewById(R.id.videos);
        personagens = findViewById(R.id.personagens);
        sensor = findViewById(R.id.sensor);

        audios.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirAudios();
            }
        });

        videos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVideos();
            }
        });

        personagens.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirPersonagens();
            }
        });

        sensor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirSensor();
            }
        });

    }

    public void abrirAudios(){
        Intent janelaA = new Intent(this, Audios.class);
        startActivity(janelaA);
    }

    public void abrirVideos(){
        Intent janelaV = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.netflix.com/br/title/80014749"));
        startActivity(janelaV);
    }

    public void abrirPersonagens(){
        Intent janelaP = new Intent(this, Personagens.class);
        startActivity(janelaP);
    }

    public void abrirSensor(){
        Intent janelaS = new Intent(this, SensorPiu.class);
        startActivity(janelaS);
    }


}
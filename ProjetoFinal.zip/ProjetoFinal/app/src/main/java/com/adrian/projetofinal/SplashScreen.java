package com.adrian.projetofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;

import com.adrian.projetofinal.atividade.MainActivity;

public class SplashScreen extends AppCompatActivity {

    private MediaPlayer musica;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        //mapeamento do arquivo .mp3 e o start na música.
        musica = MediaPlayer.create(this, R.raw.abertura);
        musica.start();

        //ocultar a barra de ação do android e configurar a activity para a tela cheia.
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        //Novo manipulador que controla o método postDelayed para abrir o activity em um tempo especificado.
        //Declaramos o método finish(); para destruir o SplashScreen impossibilitando assim que o usuário
        //possa retornar com o voltar do device.
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(getBaseContext(), MainActivity.class));
                finish();
                musica.stop();
            }
        },2000);

    }
}
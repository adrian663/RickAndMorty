package com.adrian.projetofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.TextView;

public class SensorPiu extends AppCompatActivity implements SensorEventListener {

    private Sensor proximidade;
    private SensorManager medir;
    private TextView visual;
    MediaPlayer mp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensorpiu);

        //ocultar a barra de ação do android e configurar a activity para a tela cheia.
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        medir = (SensorManager) this.getSystemService(SENSOR_SERVICE);
        proximidade = medir.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        visual = findViewById(R.id.visual);
        mp = MediaPlayer.create(this, R.raw.piu);




    }

    @Override
    protected void onResume() {
        medir.registerListener(this, proximidade, SensorManager. SENSOR_DELAY_NORMAL);
        super.onResume();
    }

    @Override
    protected void onPause() {
        medir.unregisterListener(this, proximidade);
        super.onPause();
    }


    @Override
    public void onSensorChanged(SensorEvent event) {
        if(event.values[0] == 0 ){
            mp.start();

        }
        else{

        }

    }

    @Override
    public void onAccuracyChanged(android.hardware.Sensor sensor, int accuracy) {

    }



    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

}